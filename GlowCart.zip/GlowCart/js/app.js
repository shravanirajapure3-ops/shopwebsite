/* ==========================================================================
   GlowCart — Shared UI behavior (navbar, mobile menu, wishlist, newsletter)
   ========================================================================== */

function initMobileMenu() {
  const toggle = document.querySelector(".menu-toggle");
  const panel = document.querySelector(".mobile-panel");
  if (!toggle || !panel) return;
  toggle.addEventListener("click", () => {
    panel.classList.toggle("open");
  });
  panel.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => panel.classList.remove("open"))
  );
}

function initNavSearch() {
  document.querySelectorAll("[data-nav-search]").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = form.querySelector("input");
      const q = encodeURIComponent(input.value.trim());
      window.location.href = "shop.html" + (q ? "?search=" + q : "");
    });
  });
}

/* Wires up every .wish-btn[data-id] on the page: sets initial active
   state from storage and toggles on click without navigating. */
function initWishButtons(scope = document) {
  scope.querySelectorAll(".wish-btn[data-id]").forEach((btn) => {
    const id = btn.getAttribute("data-id");
    btn.classList.toggle("active", isWishlisted(id));
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleWishlist(id);
    });
  });
}

function initNewsletterForms() {
  document.querySelectorAll(".newsletter-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const input = form.querySelector("input");
      if (!input.value.trim()) return;
      showToast("You're subscribed! Welcome to GlowCart 🌸", "add");
      form.reset();
    });
  });
}

/* Builds the little product-media block markup (gradient bg + emoji glyph)
   shared by cards across pages. */
function mediaGlyph(product, size = "") {
  return `<div class="product-media ${product.bg}">
    <span class="glyph" ${size ? `style="font-size:${size}"` : ""}>${product.glyph}</span>
  </div>`;
}

function starsMarkup(rating) {
  return `<span class="stars">${starString(rating)}</span>`;
}

/* Renders a single product card, returns HTML string */
function productCardHTML(p) {
  const discount = p.oldPrice ? Math.round(100 - (p.price / p.oldPrice) * 100) : null;
  return `
  <div class="product-card fade-up">
    <a href="product.html?id=${p.id}" class="product-media ${p.bg}" style="text-decoration:none">
      <span class="glyph">${p.glyph}</span>
      ${p.bestSeller ? `<span class="product-tag">Bestseller</span>` : ""}
      ${discount ? `<span class="product-tag sale" style="left:auto;right:56px;">-${discount}%</span>` : ""}
      <button class="wish-btn" data-id="${p.id}" aria-label="Save to wishlist">
        <svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.1C.4 8.1 2 4.5 5.6 4c2-.3 3.8.6 5 2.2C11.8 4.6 13.6 3.7 15.6 4c3.6.5 5.2 4.1 3.6 7.9C19.5 16.4 12 21 12 21z"/></svg>
      </button>
    </a>
    <div class="product-info">
      <span class="product-cat">${getCategoryMeta(p.category)?.label || p.category}</span>
      <a href="product.html?id=${p.id}"><h3 class="product-name">${p.name}</h3></a>
      <div class="product-rating">${starsMarkup(p.rating)}<span>${p.rating} (${p.reviews})</span></div>
      <div class="product-price-row">
        <span class="price">${formatPrice(p.price)}</span>
        ${p.oldPrice ? `<span class="price-old">${formatPrice(p.oldPrice)}</span>` : ""}
        ${discount ? `<span class="discount-pill">Save ${discount}%</span>` : ""}
      </div>
      <div class="product-actions">
        <button class="add-cart-btn" data-add="${p.id}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>
          Add to Cart
        </button>
      </div>
    </div>
  </div>`;
}

/* Wires up every [data-add] button within scope to add that product to cart */
function initAddToCartButtons(scope = document) {
  scope.querySelectorAll("[data-add]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      addToCart(btn.getAttribute("data-add"));
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initMobileMenu();
  initNavSearch();
  initNewsletterForms();
});
