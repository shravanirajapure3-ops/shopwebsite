/* ==========================================================================
   GlowCart — Auth page (tab switching + mock submit)
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const tabButtons = document.querySelectorAll(".auth-tabs button");
  tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      tabButtons.forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".auth-form-panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.getAttribute("data-tab")).classList.add("active");
    });
  });

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      showToast("Welcome back! You're logged in.", "add");
      setTimeout(() => (window.location.href = "index.html"), 900);
    });
  }

  const signupForm = document.getElementById("signupForm");
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();
      showToast("Account created — welcome to GlowCart!", "add");
      setTimeout(() => (window.location.href = "index.html"), 900);
    });
  }
});
