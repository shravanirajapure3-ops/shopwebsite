/* ==========================================================================
   GlowCart — Product Catalog
   Each product: id, name, category, price, oldPrice(optional), rating,
   reviews count, glyph (emoji visual), bg (css class), description, stock,
   bestSeller, featured
   ========================================================================== */

const CATEGORIES = [
  { id: "makeup",    label: "Makeup",    icon: "💄" },
  { id: "skincare",  label: "Skincare",  icon: "🌿" },
  { id: "haircare",  label: "Haircare",  icon: "🧴" },
  { id: "fragrance", label: "Fragrance", icon: "🌸" },
  { id: "lipsticks", label: "Lipsticks", icon: "💋" },
  { id: "facecare",  label: "Face Care", icon: "✨" },
  { id: "bodycare",  label: "Body Care", icon: "🛁" },
];

const PRODUCTS = [
  {
    id: "gc-001", name: "Velvet Bloom Blush Duo", category: "makeup",
    price: 24.0, oldPrice: 30.0, rating: 4.8, reviews: 214, glyph: "💄", bg: "bg-makeup",
    description: "A silky, buildable duo blush that melts into skin for a soft, flushed-cheek finish. Formulated with rosehip oil for a dewy glow that lasts all day.",
    stock: 34, bestSeller: true, featured: true,
  },
  {
    id: "gc-002", name: "Featherlight Foundation", category: "makeup",
    price: 32.0, rating: 4.6, reviews: 158, glyph: "🧴", bg: "bg-makeup",
    description: "Buildable, breathable coverage with a natural satin finish. Lightweight formula wears comfortably from morning to night without settling into fine lines.",
    stock: 41, bestSeller: false, featured: true,
  },
  {
    id: "gc-003", name: "Silk Brow Definer", category: "makeup",
    price: 16.0, oldPrice: 20.0, rating: 4.5, reviews: 96, glyph: "🖌️", bg: "bg-makeup",
    description: "Ultra-fine tip for hair-like strokes and a tinted gel to set brows in place all day. Smudge-proof and water-resistant.",
    stock: 52, bestSeller: false, featured: false,
  },
  {
    id: "gc-004", name: "Hydra Glow Serum", category: "skincare",
    price: 38.0, rating: 4.9, reviews: 342, glyph: "💧", bg: "bg-skincare",
    description: "A featherweight serum packed with hyaluronic acid and niacinamide to deeply hydrate, plump, and restore radiance to tired skin.",
    stock: 28, bestSeller: true, featured: true,
  },
  {
    id: "gc-005", name: "Rosewater Calm Toner", category: "skincare",
    price: 19.0, oldPrice: 24.0, rating: 4.7, reviews: 187, glyph: "🌹", bg: "bg-skincare",
    description: "Alcohol-free toner infused with rosewater and chamomile to soothe, balance, and prep skin for the rest of your routine.",
    stock: 60, bestSeller: false, featured: false,
  },
  {
    id: "gc-006", name: "Overnight Renewal Cream", category: "skincare",
    price: 45.0, rating: 4.8, reviews: 129, glyph: "🌙", bg: "bg-skincare",
    description: "A rich night cream with peptides and squalane that works while you sleep to visibly smooth texture and restore softness by morning.",
    stock: 22, bestSeller: true, featured: false,
  },
  {
    id: "gc-007", name: "Argan Repair Hair Oil", category: "haircare",
    price: 22.0, rating: 4.6, reviews: 143, glyph: "✨", bg: "bg-haircare",
    description: "Lightweight, fast-absorbing oil that tames frizz, adds shine, and repairs split ends without leaving hair greasy.",
    stock: 37, bestSeller: false, featured: true,
  },
  {
    id: "gc-008", name: "Volume Boost Shampoo", category: "haircare",
    price: 18.0, oldPrice: 22.0, rating: 4.4, reviews: 88, glyph: "🧴", bg: "bg-haircare",
    description: "Sulfate-free formula that gently cleanses while adding fullness and bounce to fine, flat hair.",
    stock: 45, bestSeller: false, featured: false,
  },
  {
    id: "gc-009", name: "Silk Smooth Hair Mask", category: "haircare",
    price: 26.0, rating: 4.7, reviews: 111, glyph: "🧖", bg: "bg-haircare",
    description: "Deep-conditioning weekly treatment with keratin and silk proteins to restore softness and manageability.",
    stock: 30, bestSeller: false, featured: false,
  },
  {
    id: "gc-010", name: "Blush Petal Eau de Parfum", category: "fragrance",
    price: 62.0, rating: 4.9, reviews: 256, glyph: "🌸", bg: "bg-fragrance",
    description: "A romantic bouquet of peony, soft musk, and warm vanilla. Long-lasting and perfect for everyday wear.",
    stock: 18, bestSeller: true, featured: true,
  },
  {
    id: "gc-011", name: "Midnight Orchid Perfume", category: "fragrance",
    price: 68.0, oldPrice: 78.0, rating: 4.7, reviews: 134, glyph: "🌺", bg: "bg-fragrance",
    description: "A deep, sensual scent layering black orchid, amber, and sandalwood for evening elegance.",
    stock: 15, bestSeller: false, featured: false,
  },
  {
    id: "gc-012", name: "Citrus Bloom Body Mist", category: "fragrance",
    price: 24.0, rating: 4.5, reviews: 97, glyph: "🍋", bg: "bg-fragrance",
    description: "A refreshing everyday mist with notes of bergamot, white tea, and soft florals.",
    stock: 48, bestSeller: false, featured: false,
  },
  {
    id: "gc-013", name: "Matte Muse Lipstick", category: "lipsticks",
    price: 20.0, rating: 4.8, reviews: 302, glyph: "💋", bg: "bg-lipsticks",
    description: "A weightless matte lipstick with full-pigment color payoff in one swipe. Comfortable, non-drying formula.",
    stock: 55, bestSeller: true, featured: true,
  },
  {
    id: "gc-014", name: "Glossy Tint Lip Oil", category: "lipsticks",
    price: 17.0, oldPrice: 21.0, rating: 4.6, reviews: 176, glyph: "✨", bg: "bg-lipsticks",
    description: "A nourishing lip oil with a sheer wash of color and a glassy, high-shine finish.",
    stock: 62, bestSeller: false, featured: true,
  },
  {
    id: "gc-015", name: "Velvet Rouge Lip Crayon", category: "lipsticks",
    price: 15.0, rating: 4.5, reviews: 84, glyph: "🖍️", bg: "bg-lipsticks",
    description: "A creamy, self-sharpening crayon for precise application and rich, velvety color in one swipe.",
    stock: 40, bestSeller: false, featured: false,
  },
  {
    id: "gc-016", name: "Radiance Vitamin C Cream", category: "facecare",
    price: 34.0, rating: 4.8, reviews: 210, glyph: "🍊", bg: "bg-facecare",
    description: "Brightening daily moisturizer with stabilized vitamin C to even tone and fade the look of dark spots.",
    stock: 33, bestSeller: true, featured: false,
  },
  {
    id: "gc-017", name: "Gentle Clay Cleanser", category: "facecare",
    price: 21.0, oldPrice: 26.0, rating: 4.6, reviews: 118, glyph: "🧼", bg: "bg-facecare",
    description: "A creamy clay-based cleanser that lifts impurities without stripping skin's natural moisture barrier.",
    stock: 50, bestSeller: false, featured: false,
  },
  {
    id: "gc-018", name: "Soothing Sheet Mask Set", category: "facecare",
    price: 28.0, rating: 4.7, reviews: 92, glyph: "🎭", bg: "bg-facecare",
    description: "A set of 5 hydrating sheet masks infused with centella asiatica to calm redness and irritation.",
    stock: 26, bestSeller: false, featured: true,
  },
  {
    id: "gc-019", name: "Whipped Shea Body Butter", category: "bodycare",
    price: 23.0, rating: 4.9, reviews: 264, glyph: "🧈", bg: "bg-bodycare",
    description: "Ultra-rich whipped butter with shea and cocoa that melts into skin, leaving it soft for 48 hours.",
    stock: 44, bestSeller: true, featured: true,
  },
  {
    id: "gc-020", name: "Sugar Glow Body Scrub", category: "bodycare",
    price: 19.0, oldPrice: 24.0, rating: 4.5, reviews: 76, glyph: "🍯", bg: "bg-bodycare",
    description: "A fine sugar scrub with sweet almond oil that gently exfoliates for smoother, glowing skin.",
    stock: 39, bestSeller: false, featured: false,
  },
  {
    id: "gc-021", name: "Silk Hand & Nail Cream", category: "bodycare",
    price: 14.0, rating: 4.4, reviews: 61, glyph: "🤍", bg: "bg-bodycare",
    description: "Fast-absorbing hand cream with vitamin E to soften and protect without any greasy residue.",
    stock: 58, bestSeller: false, featured: false,
  },
];

function getProductById(id) {
  return PRODUCTS.find((p) => p.id === id);
}

function getCategoryMeta(catId) {
  return CATEGORIES.find((c) => c.id === catId);
}

function formatPrice(n) {
  return "$" + n.toFixed(2);
}

function starString(rating) {
  const full = Math.round(rating);
  return "★★★★★☆☆☆☆☆".slice(5 - full, 10 - full);
}
