/* ==========================================================================
   GlowCart — Product Details page logic
   ========================================================================== */

let currentQty = 1;

function getProductIdFromURL() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

function renderProductPage() {
  const id = getProductIdFromURL();
  const product = getProductById(id) || PRODUCTS[0];
  const layout = document.getElementById("pdLayout");
  const discount = product.oldPrice ? Math.round(100 - (product.price / product.oldPrice) * 100) : null;
  const lowStock = product.stock <= 15;

  document.title = product.name + " — GlowCart";
  document.getElementById("crumbName").textContent = product.name;

  layout.innerHTML = `
    <div class="fade-up">
      <div class="pd-media ${product.bg}">
        <span class="glyph">${product.glyph}</span>
      </div>
      <div class="pd-thumbs">
        <div class="thumb ${product.bg} active"><span>${product.glyph}</span></div>
        <div class="thumb" style="background:var(--blush)"><span>🎀</span></div>
        <div class="thumb" style="background:var(--blush)"><span>📦</span></div>
      </div>
    </div>

    <div class="fade-up">
      <span class="pd-cat">${getCategoryMeta(product.category)?.label || product.category}</span>
      <h1 class="pd-title">${product.name}</h1>
      <div class="pd-rating">
        <span class="stars">${starString(product.rating)}</span>
        <span>${product.rating} · ${product.reviews} reviews</span>
      </div>

      <div class="pd-price-row">
        <span class="price">${formatPrice(product.price)}</span>
        ${product.oldPrice ? `<span class="price-old">${formatPrice(product.oldPrice)}</span>` : ""}
        ${discount ? `<span class="discount-pill">Save ${discount}%</span>` : ""}
      </div>

      <p class="pd-desc">${product.description}</p>

      <div class="pd-meta">
        <span class="meta-pill">🌿 Cruelty-free</span>
        <span class="meta-pill">🚫 No parabens</span>
        <span class="meta-pill">♻️ Recyclable packaging</span>
      </div>

      <div class="pd-stock ${lowStock ? "low" : ""}">
        ${lowStock ? "⚠️" : "✓"} ${product.stock > 0 ? `${product.stock} units available` : "Out of stock"}
      </div>

      <div style="margin-top:22px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
        <div class="qty-selector">
          <button id="qtyMinus" aria-label="Decrease quantity">−</button>
          <span id="qtyVal">1</span>
          <button id="qtyPlus" aria-label="Increase quantity">+</button>
        </div>
        <span style="font-size:13px;color:var(--muted);">Max ${product.stock} per order</span>
      </div>

      <div class="pd-actions">
        <button class="btn btn-secondary" id="addToCartBtn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>
          Add to Cart
        </button>
        <button class="btn btn-primary" id="buyNowBtn">Buy Now</button>
        <button class="wish-btn" data-id="${product.id}" aria-label="Save to wishlist">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.1C.4 8.1 2 4.5 5.6 4c2-.3 3.8.6 5 2.2C11.8 4.6 13.6 3.7 15.6 4c3.6.5 5.2 4.1 3.6 7.9C19.5 16.4 12 21 12 21z"/></svg>
        </button>
      </div>

      <div class="pd-trust">
        <div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a4 4 0 0 1 8 0v2"/></svg> Secure checkout</div>
        <div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 12h5l2-8 4 16 2-8h5"/></svg> Free returns in 30 days</div>
        <div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="1" y="6" width="16" height="12" rx="2"/><path d="M17 10h4l2 3v3h-6z"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg> Ships in 1–2 days</div>
      </div>
    </div>
  `;

  currentQty = 1;
  document.getElementById("qtyVal").textContent = currentQty;

  document.getElementById("qtyMinus").addEventListener("click", () => {
    currentQty = Math.max(1, currentQty - 1);
    document.getElementById("qtyVal").textContent = currentQty;
  });
  document.getElementById("qtyPlus").addEventListener("click", () => {
    currentQty = Math.min(product.stock, currentQty + 1);
    document.getElementById("qtyVal").textContent = currentQty;
  });
  document.getElementById("addToCartBtn").addEventListener("click", () => {
    addToCart(product.id, currentQty);
  });
  document.getElementById("buyNowBtn").addEventListener("click", () => {
    addToCart(product.id, currentQty);
    window.location.href = "cart.html";
  });

  initWishButtons(layout);

  // related products
  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
  const relatedWrap = document.getElementById("relatedWrap");
  if (related.length) {
    relatedWrap.innerHTML = `
      <div class="section-head related-heading" style="text-align:left;align-items:flex-start;margin-bottom:26px;">
        <span class="eyebrow">You may also like</span>
        <h2>More from ${getCategoryMeta(product.category)?.label || "this collection"}</h2>
      </div>
      <div class="product-grid" id="relatedGrid"></div>
    `;
    document.getElementById("relatedGrid").innerHTML = related.map(productCardHTML).join("");
    initWishButtons(relatedWrap);
    initAddToCartButtons(relatedWrap);
  }
}

document.addEventListener("DOMContentLoaded", renderProductPage);
