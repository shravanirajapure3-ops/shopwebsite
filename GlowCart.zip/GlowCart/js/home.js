/* ==========================================================================
   GlowCart — Home page rendering
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const catStrip = document.getElementById("categoryStrip");
  if (catStrip) {
    catStrip.innerHTML = CATEGORIES.map(
      (c) => `
      <a href="shop.html?cat=${c.id}" class="category-card">
        <div class="ic cat-ic-${c.id}">${c.icon}</div>
        <span>${c.label}</span>
      </a>`
    ).join("");
  }

  const featuredGrid = document.getElementById("featuredGrid");
  if (featuredGrid) {
    const featured = PRODUCTS.filter((p) => p.featured).slice(0, 4);
    featuredGrid.innerHTML = featured.map(productCardHTML).join("");
    initWishButtons(featuredGrid);
    initAddToCartButtons(featuredGrid);
  }

  const bestGrid = document.getElementById("bestSellerGrid");
  if (bestGrid) {
    const best = PRODUCTS.filter((p) => p.bestSeller).slice(0, 4);
    bestGrid.innerHTML = best.map(productCardHTML).join("");
    initWishButtons(bestGrid);
    initAddToCartButtons(bestGrid);
  }
});
