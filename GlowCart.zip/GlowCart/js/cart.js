/* ==========================================================================
   GlowCart — Cart, Wishlist & Toast utilities
   Persists to localStorage so state survives across pages.
   ========================================================================== */

const CART_KEY = "glowcart_cart";
const WISH_KEY = "glowcart_wishlist";
const DELIVERY_FLAT = 4.99;
const FREE_DELIVERY_THRESHOLD = 50;

/* ---------------- storage helpers ---------------- */
function readCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function writeCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}
function readWishlist() {
  try {
    return JSON.parse(localStorage.getItem(WISH_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function writeWishlist(list) {
  localStorage.setItem(WISH_KEY, JSON.stringify(list));
  updateWishBadge();
}

/* ---------------- cart operations ---------------- */
function addToCart(productId, qty = 1) {
  const cart = readCart();
  const existing = cart.find((i) => i.id === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: productId, qty });
  }
  writeCart(cart);
  const product = getProductById(productId);
  showToast(`${product ? product.name : "Item"} added to cart`, "add");
}

function removeFromCart(productId) {
  const cart = readCart().filter((i) => i.id !== productId);
  writeCart(cart);
  renderCartIfPresent();
  showToast("Item removed from cart", "remove");
}

function setQty(productId, qty) {
  const cart = readCart();
  const item = cart.find((i) => i.id === productId);
  if (!item) return;
  item.qty = Math.max(1, qty);
  writeCart(cart);
  renderCartIfPresent();
}

function cartCount() {
  return readCart().reduce((sum, i) => sum + i.qty, 0);
}

function cartTotals() {
  const cart = readCart();
  let subtotal = 0;
  cart.forEach((item) => {
    const p = getProductById(item.id);
    if (p) subtotal += p.price * item.qty;
  });
  const delivery = subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FLAT;
  const total = subtotal + delivery;
  return { subtotal, delivery, total };
}

/* ---------------- wishlist operations ---------------- */
function toggleWishlist(productId) {
  let list = readWishlist();
  const product = getProductById(productId);
  if (list.includes(productId)) {
    list = list.filter((id) => id !== productId);
    writeWishlist(list);
    showToast(`Removed from wishlist`, "remove");
  } else {
    list.push(productId);
    writeWishlist(list);
    showToast(`${product ? product.name : "Item"} saved to wishlist`, "add");
  }
  document.querySelectorAll(`.wish-btn[data-id="${productId}"]`).forEach((btn) => {
    btn.classList.toggle("active", list.includes(productId));
  });
}
function isWishlisted(productId) {
  return readWishlist().includes(productId);
}

/* ---------------- badges ---------------- */
function updateCartBadge() {
  document.querySelectorAll(".cart-badge").forEach((el) => {
    const count = cartCount();
    el.textContent = count;
    el.style.display = count > 0 ? "flex" : "none";
  });
}
function updateWishBadge() {
  document.querySelectorAll(".wish-badge").forEach((el) => {
    const count = readWishlist().length;
    el.textContent = count;
    el.style.display = count > 0 ? "flex" : "none";
  });
}

/* ---------------- toast ---------------- */
function showToast(message, type = "add") {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  const toast = document.createElement("div");
  toast.className = "toast" + (type === "remove" ? " remove" : "");
  toast.innerHTML = `<span class="tick">${type === "remove" ? "✕" : "✓"}</span><span>${message}</span>`;
  stack.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("hide");
    setTimeout(() => toast.remove(), 300);
  }, 2600);
}

/* ---------------- re-render hook (defined per-page) ---------------- */
function renderCartIfPresent() {
  if (typeof renderCartPage === "function") renderCartPage();
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  updateWishBadge();
});
