/* ==========================================================================
   GlowCart — Shop page logic (filter, search, sort)
   ========================================================================== */

const shopState = {
  cat: "all",
  search: "",
  maxPrice: 80,
  bestOnly: false,
  saleOnly: false,
  wishlistOnly: false,
  sort: "popularity",
};

function readShopParams() {
  const params = new URLSearchParams(window.location.search);
  if (params.get("cat")) shopState.cat = params.get("cat");
  if (params.get("search")) shopState.search = params.get("search");
  if (params.get("wishlist") === "1") shopState.wishlistOnly = true;
}

function buildCategoryFilters() {
  const wrap = document.getElementById("categoryFilters");
  const counts = {};
  PRODUCTS.forEach((p) => (counts[p.category] = (counts[p.category] || 0) + 1));

  let html = `
    <label class="chip-option">
      <span>All Products</span>
      <input type="radio" name="catFilter" value="all" ${shopState.cat === "all" ? "checked" : ""} />
    </label>`;
  CATEGORIES.forEach((c) => {
    html += `
    <label class="chip-option">
      <span>${c.icon} ${c.label}</span>
      <input type="radio" name="catFilter" value="${c.id}" ${shopState.cat === c.id ? "checked" : ""} />
    </label>`;
  });
  wrap.innerHTML = html;

  wrap.querySelectorAll('input[name="catFilter"]').forEach((input) => {
    input.addEventListener("change", () => {
      shopState.cat = input.value;
      renderShop();
    });
  });
}

function getFilteredSorted() {
  let list = PRODUCTS.filter((p) => {
    if (shopState.cat !== "all" && p.category !== shopState.cat) return false;
    if (shopState.search && !p.name.toLowerCase().includes(shopState.search.toLowerCase())) return false;
    if (p.price > shopState.maxPrice) return false;
    if (shopState.bestOnly && !p.bestSeller) return false;
    if (shopState.saleOnly && !p.oldPrice) return false;
    if (shopState.wishlistOnly && !isWishlisted(p.id)) return false;
    return true;
  });

  switch (shopState.sort) {
    case "price-asc":
      list.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      list.sort((a, b) => b.price - a.price);
      break;
    case "rating":
      list.sort((a, b) => b.rating - a.rating);
      break;
    default: // popularity -> bestsellers first, then reviews desc
      list.sort((a, b) => (b.bestSeller - a.bestSeller) || (b.reviews - a.reviews));
  }
  return list;
}

function renderShop() {
  const grid = document.getElementById("shopGrid");
  const empty = document.getElementById("emptyState");
  const list = getFilteredSorted();

  document.getElementById("resultCount").textContent =
    `${list.length} product${list.length !== 1 ? "s" : ""} found`;

  const catMeta = getCategoryMeta(shopState.cat);
  document.getElementById("shopTitle").textContent = catMeta ? catMeta.label : "Shop all products";
  document.getElementById("crumbLabel").textContent = catMeta ? catMeta.label : "Shop";

  if (list.length === 0) {
    grid.style.display = "none";
    empty.style.display = "block";
    return;
  }
  grid.style.display = "grid";
  empty.style.display = "none";
  grid.innerHTML = list.map(productCardHTML).join("");
  initWishButtons(grid);
  initAddToCartButtons(grid);
}

document.addEventListener("DOMContentLoaded", () => {
  readShopParams();
  buildCategoryFilters();

  const searchInput = document.getElementById("shopSearchInput");
  searchInput.value = shopState.search;
  searchInput.addEventListener("input", () => {
    shopState.search = searchInput.value;
    renderShop();
  });

  const priceRange = document.getElementById("priceRange");
  priceRange.addEventListener("input", () => {
    shopState.maxPrice = Number(priceRange.value);
    document.getElementById("priceRangeVal").textContent =
      shopState.maxPrice >= 80 ? "Up to $80" : "Up to $" + shopState.maxPrice;
    renderShop();
  });

  document.getElementById("bestSellerFilter").addEventListener("change", (e) => {
    shopState.bestOnly = e.target.checked;
    renderShop();
  });
  document.getElementById("saleFilter").addEventListener("change", (e) => {
    shopState.saleOnly = e.target.checked;
    renderShop();
  });
  const wishlistCb = document.getElementById("wishlistFilter");
  wishlistCb.checked = shopState.wishlistOnly;
  wishlistCb.addEventListener("change", (e) => {
    shopState.wishlistOnly = e.target.checked;
    renderShop();
  });

  document.getElementById("sortSelect").addEventListener("change", (e) => {
    shopState.sort = e.target.value;
    renderShop();
  });

  document.getElementById("clearFilters").addEventListener("click", () => {
    shopState.cat = "all";
    shopState.search = "";
    shopState.maxPrice = 80;
    shopState.bestOnly = false;
    shopState.saleOnly = false;
    shopState.wishlistOnly = false;
    shopState.sort = "popularity";
    searchInput.value = "";
    priceRange.value = 80;
    document.getElementById("priceRangeVal").textContent = "Up to $80";
    document.getElementById("bestSellerFilter").checked = false;
    document.getElementById("saleFilter").checked = false;
    wishlistCb.checked = false;
    document.getElementById("sortSelect").value = "popularity";
    buildCategoryFilters();
    renderShop();
  });

  // Mobile filter panel open/close
  const panel = document.getElementById("filterPanel");
  document.getElementById("openFilters").addEventListener("click", () => panel.classList.add("open"));
  document.getElementById("closeFilters").addEventListener("click", () => panel.classList.remove("open"));

  renderShop();
});
