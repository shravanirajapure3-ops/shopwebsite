/* ==========================================================================
   GlowCart — Contact form handling
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contactForm");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Message sent — we'll be in touch soon!", "add");
    form.reset();
  });
});
