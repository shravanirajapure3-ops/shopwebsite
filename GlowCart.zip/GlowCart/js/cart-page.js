/* ==========================================================================
   GlowCart — Cart page rendering
   ========================================================================== */

function renderCartPage() {
  const container = document.getElementById("cartContainer");
  if (!container) return;
  const cart = readCart();

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="empty-cart">
        <span class="glyph">🛍️</span>
        <h2>Your cart is empty</h2>
        <p>Looks like you haven't added anything yet. Let's fix that.</p>
        <a href="shop.html" class="btn btn-primary">Start Shopping</a>
      </div>`;
    return;
  }

  const { subtotal, delivery, total } = cartTotals();

  const rowsHTML = cart
    .map((item) => {
      const p = getProductById(item.id);
      if (!p) return "";
      return `
      <div class="cart-row" data-row="${p.id}">
        <div class="cart-thumb ${p.bg}"><span>${p.glyph}</span></div>
        <div>
          <a href="product.html?id=${p.id}" class="cart-item-name">${p.name}</a>
          <div class="cart-item-cat">${getCategoryMeta(p.category)?.label || p.category}</div>
          <div class="cart-item-price">${formatPrice(p.price)} each</div>
          <span class="cart-remove" data-remove="${p.id}">Remove</span>
        </div>
        <div class="qty-selector">
          <button data-minus="${p.id}" aria-label="Decrease quantity">−</button>
          <span>${item.qty}</span>
          <button data-plus="${p.id}" aria-label="Increase quantity">+</button>
        </div>
        <div class="cart-qty-total">
          <span class="line-total">${formatPrice(p.price * item.qty)}</span>
        </div>
      </div>`;
    })
    .join("");

  container.innerHTML = `
    <div class="cart-layout">
      <div class="cart-list">${rowsHTML}</div>
      <div class="summary-card">
        <h3>Order Summary</h3>
        <div class="summary-row"><span>Subtotal</span><span>${formatPrice(subtotal)}</span></div>
        <div class="summary-row"><span>Delivery</span><span>${delivery === 0 ? "Free" : formatPrice(delivery)}</span></div>
        ${
          delivery > 0
            ? `<div class="summary-row" style="font-size:12.5px;color:var(--petal-deep);">Add ${formatPrice(FREE_DELIVERY_THRESHOLD - subtotal)} more for free delivery</div>`
            : ""
        }
        <div class="promo-row">
          <input type="text" placeholder="Promo code" />
          <button class="btn btn-secondary btn-sm">Apply</button>
        </div>
        <div class="summary-row total"><span>Total</span><span>${formatPrice(total)}</span></div>
        <button class="btn btn-primary btn-block" style="margin-top:20px;" id="checkoutBtn">Proceed to Checkout</button>
        <a href="shop.html" style="display:block;text-align:center;margin-top:14px;font-size:13px;font-weight:700;color:var(--plum-soft);">← Continue Shopping</a>
      </div>
    </div>
  `;

  container.querySelectorAll("[data-minus]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-minus");
      const item = readCart().find((i) => i.id === id);
      if (item) setQty(id, item.qty - 1 <= 0 ? 1 : item.qty - 1);
      if (item && item.qty <= 1) return;
    })
  );
  container.querySelectorAll("[data-plus]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-plus");
      const item = readCart().find((i) => i.id === id);
      if (item) setQty(id, item.qty + 1);
    })
  );
  container.querySelectorAll("[data-remove]").forEach((btn) =>
    btn.addEventListener("click", () => removeFromCart(btn.getAttribute("data-remove")))
  );

  const checkoutBtn = document.getElementById("checkoutBtn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      document.getElementById("checkoutModal").style.display = "flex";
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  renderCartPage();
  const modal = document.getElementById("checkoutModal");
  const closeBtn = document.getElementById("closeCheckoutModal");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
      writeCart([]);
      renderCartPage();
      window.location.href = "shop.html";
    });
  }
});
